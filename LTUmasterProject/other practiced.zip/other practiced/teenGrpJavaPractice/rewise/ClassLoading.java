package rewise;

public class ClassLoading
{
	public static void main(String[] args) {
		//A a1=new A();
		A.test();
		A a2=new A();
		//A a3;
	}
	
	
}
 

 
