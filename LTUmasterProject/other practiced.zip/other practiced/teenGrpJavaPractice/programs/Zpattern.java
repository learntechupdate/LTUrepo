
public class Zpattern {

	public static void main(String[] args)
	{

		for (int i = 1; i <= 4; i++) 
		{
			if(i==1||i==4)
			{
				System.out.println("****");
			}
			else if(i==2)
			{
				System.out.println("  * ");
			}
			else if(i==3)
			{
				System.out.println(" *  ");
			}
		}
	}

}
