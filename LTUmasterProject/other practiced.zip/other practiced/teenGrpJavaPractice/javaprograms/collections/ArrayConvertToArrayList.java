package javaprograms.collections;

import java.util.ArrayList;

public class ArrayConvertToArrayList {
	
	public static void main(String[] args) {
		
		
		
		
		
	}

}
