package javaprograms.reverse;


public class Reverse {
	
	public static void main(String[] args) 
	{
		//Scanner sc = new Scanner(System.in);
		StringBuffer s = new StringBuffer("User Name is XYZ");
		
		
		System.out.println("Reverse of User Name is "+s.reverse());
			
	
	}

}
