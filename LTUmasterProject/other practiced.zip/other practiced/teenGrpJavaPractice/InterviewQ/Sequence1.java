package javainterview;

/* my name is touheed print as
 * 2 4 2 7 */
public class Sequence1 {
	
	public static void main(String[] args) 
	{
		String s1= "My name is Touheed";
		
		int len = s1.length();
		System.out.println(len);
		for (int i = 0; i < len; i++) 
		{
			
			
		}
		
	}

}
