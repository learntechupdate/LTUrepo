package rewise2;

public class B

{
	static void disStatic()
	 {
		  System.out.println("Disp Static");	 
	 }
	  void dis1()
	 {
		  System.out.println("Disp 1");	 
	 }
	  void dis2()
		 {
			  System.out.println("Disp 2");	 
		 }
}