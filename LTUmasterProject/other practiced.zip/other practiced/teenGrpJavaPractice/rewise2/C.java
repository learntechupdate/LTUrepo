package rewise2;

class C extends B

{
	
	 void cMethod()
	 
	 {
		 //B b=new B();
		 //b.dis1();
		super.dis1();
		 //super.dis2();
		 System.out.println(" C class Method");
	 }
	 
}