package selenium;

public class Abstarct {
	
		public static void main(String[] are)
		{
			
			Project project=new Project();
			project.companyDetails();
			project.empDetails();
			project.projectDetails();
			
		}
		Abstarct()
		{
			System.out.println("hghg");
		}
		{
		}
		static
		{
		}
		void main()
		{
		}
		static int x;
		int y;
		  
		}


