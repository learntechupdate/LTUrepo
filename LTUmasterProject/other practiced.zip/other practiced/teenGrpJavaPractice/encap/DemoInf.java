package selenium;

public interface DemoInf {
	public void companyDetails();
	public abstract void empDetails();
	public abstract void projectDetails();


	
}

class Demo implements DemoInf
{

	public void companyDetails() {
		// TODO Auto-generated method stub
		
	}

	public void empDetails() {
		// TODO Auto-generated method stub
		
	}

	public void projectDetails() {
		// TODO Auto-generated method stub
		
	}

	public int DemoInf() {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
