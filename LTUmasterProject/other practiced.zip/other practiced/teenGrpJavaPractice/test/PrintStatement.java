package test;

public class PrintStatement {
	public static void main(String[] arg){
		int x=10;
		int y=21;
		if (x!=y){
		System.out.print("Hi\n");}
		else{
		System.out.print("Touheed here");}
	}

}