package test;

public class Demo2 {
	public static void main(String[] arg){
		System.out.println("Good morning");
	}

}
