package learningGD;

public class Inheritance {

	public static void main(String[] args)
	{
		Sub s = new Sub();
		s.display();
	}
}
