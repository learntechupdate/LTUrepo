package learningGD;

public interface BankDetails 
{
	void accountDetails(Object object);
	void loanDetails(Object object);
	void repaymentLoan(double a);
}


