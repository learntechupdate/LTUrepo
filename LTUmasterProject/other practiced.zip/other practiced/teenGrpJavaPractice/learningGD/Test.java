package learningGD;

public interface Test {
  void test();
  
}
