package methodcall;

public class Demo {
	
	public void intrestCalculation(int intrest) {
		
		System.out.println(intrest*0.3*12);
	}
	
	public static void display(String name){
		System.out.println("My name is "+ name);
	}

}
