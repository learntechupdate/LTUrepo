package methodcall.bothNonstatic;

public class Demo {
	
	public static void main(String[] args) {
		
		Run r=new Run();
		r.method1();
	}

}
