package methodcallbothstatic;

public class Demo {
	
	public static void main(String[] args) {
		
		Run.method1();
	}

}
