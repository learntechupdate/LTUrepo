package javanotes;

public class PrintDemo 
{
  public static void main(String[] args) {
	
	  System.out.println("Hello");
	  
	  System.out.println("world");
	  
	  //two different statements in same line
	  System.out.print("****");
	  System.out.println("varma");
	
	  //with backslash\  "Iam"very"bad"
	  System.out.println("\"Iam\"very\\bad");
	  
//	  System.out.println("Iam\b fit\t here\n to\f java\r sel\' ");  google it
	  
	  /*
	   * 
	   \ is used as for escape sequence in many programming languages, including Java.
         If you want to go to next line then use \n or \r,for tab use \t

       likewise to print a \ or " which are special in string literal you have to escape it with another
       \ which gives us \\ and \"
	   * 
	   */
}
}
