package javanotes;

public class PrimitiveCasting {
	
	public static void main(String[] args) {
		
		@SuppressWarnings("unused")
		long l=100;
		float flt= 10.10f; //float flt= (float) 10.10;
		int b=(int) 10.10;
		
		System.out.println(flt);
		System.out.println(b);
	}

}
