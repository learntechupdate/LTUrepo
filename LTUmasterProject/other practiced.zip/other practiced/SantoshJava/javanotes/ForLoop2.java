package javanotes;

public class ForLoop2 {
	
	public static void main(String[] args) {
		
		System.out.println("enter for loop");
		
		for (int i = 1; i <=5 ; i++) {
			int x=i+1;
			System.out.println(i+""+x);
		}
	}

}
