package javanotes;

public class ForLoop {
	
	public static void main(String[] args) {
		
		System.out.println("enter for loop");
		
		for (int i = 1; i <=3 ; i++) {
			System.out.println("line"+i);
		}
	}

}
