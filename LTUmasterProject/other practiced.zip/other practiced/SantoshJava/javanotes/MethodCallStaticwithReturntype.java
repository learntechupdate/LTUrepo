package javanotes;

public class MethodCallStaticwithReturntype {
	
	public static int add(int value1, int value2) {
		return value1+value2;
	}
	public static void main(String[] args) {
		
		int a=5;
		int b=6;
		System.out.println(add(a, b));
	}

}
